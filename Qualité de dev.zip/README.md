# POWER 4

## goals

- line up 4 pawns in a row, column or diagonal

## rules

- 2 players required
- each player plays in turn
- a player choose a column and a pawn is placed at the bottom of the column
- the game ends when a player line up 4 pawns or when the grid is full
- if the grid is full and no player line up 4 pawns, the game is a draw
- each player has a special pawn which can be used to reverse the column
- the special pawn can be used only once per game
